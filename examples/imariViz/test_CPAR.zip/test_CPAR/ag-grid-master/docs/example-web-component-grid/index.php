<?php
$key = "Web Components";
$pageTitle = "HTML 5 Grid Web Components";
$pageDescription = "How to use Agile Grid as a web component";
$pageKeyboards = "HTML 5 Javascript Grid Web Component";
include '../documentation_header.php';
?>

<div>

    <h2>Web Components</h2>

    <a href="/best-web-component-grid/index.php">The example has moved to this page.</a>

</div>

<?php include '../documentation_footer.php';?>
