<!--<hr>
<hr>
<hr>
<hr>
<hr>
<hr>

            <h4>Don't ask questions below!!!</h4>

            <p>
                Can you add to the documentation? Add a comment below to supplement the documentation.
            </p>

            <p>
                If you have a question, please ask it on <a href="/forum">the forum</a>.
            </p>

            <div id="disqus_thread"></div>
            <script type="text/javascript">
                /* * * CONFIGURATION VARIABLES * * */
                var disqus_shortname = 'angulargrid';

                /* * * DON'T EDIT BELOW THIS LINE * * */
                (function() {
                    var dsq = document.createElement('script'); dsq.type = 'text/javascript'; dsq.async = true;
                    dsq.src = '//' + disqus_shortname + '.disqus.com/embed.js';
                    (document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(dsq);
                })();
            </script>
            <noscript>Please enable JavaScript to view the <a href="https://disqus.com/?ref_noscript" rel="nofollow">comments powered by Disqus.</a></noscript>

            </div>-->

        </div>

        <hr/>

        <footer class="license">
            © Niall Crosby 2015
        </footer>
    </div>

</body>

<?php include_once("analytics.php"); ?>

</html>
