<?php
$key = "Data Grid";
$pageTitle = "AngularJS Angular Data Grid Example";
$pageDescription = "How to make a basic data table using AngularJS and Angular Grid. Follow the example below to see how a table can be put together.";
$pageKeyboards = "AngularJS Angular Data Grid Example";
include '../documentation_header.php';
?>

<div>

    <h2>AngularJS Angular Data Grid Example</h2>

    <a href="/best-angularjs-grid/index.php">The example has moved to this page.</a>

</div>

<?php include '../documentation_footer.php';?>
