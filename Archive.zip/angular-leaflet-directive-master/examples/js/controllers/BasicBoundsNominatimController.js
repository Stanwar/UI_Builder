        app.controller('BasicBoundsNominatimController', [ '$scope', function($scope) {
            angular.extend($scope, {
                bounds: {
                    address: 'Bath, UK'
                }
            });
       }]);