        app.controller("BasicFirstController", [ "$scope", function($scope) {
            // Nothing here!
        }]);